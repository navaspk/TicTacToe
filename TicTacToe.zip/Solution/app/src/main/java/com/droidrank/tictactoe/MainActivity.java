package com.droidrank.tictactoe;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{



    Button block1, block2, block3, block4, block5, block6, block7, block8, block9, restart;
    TextView result;
    boolean mState = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        block1 = (Button) findViewById(R.id.bt_block1);
        block1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block1.setText("0");
                } else {
                    mState = true;
                    block1.setText("X");
                }
                b1Clicks();
            }
        });

        block2 = (Button) findViewById(R.id.bt_block2);
        block2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block2.setText("0");
                } else {
                    mState = true;
                    block2.setText("X");
                }
            }
        });

        block3 = (Button) findViewById(R.id.bt_block3);
        block3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block3.setText("0");
                } else {
                    mState = true;
                    block3.setText("X");
                }
            }
        });

        block4 = (Button) findViewById(R.id.bt_block4);
        block4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block4.setText("0");
                } else {
                    mState = true;
                    block4.setText("X");
                }
            }
        });

        block5 = (Button) findViewById(R.id.bt_block5);
        block5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block5.setText("0");
                } else {
                    mState = true;
                    block5.setText("X");
                }
            }
        });

        block6 = (Button) findViewById(R.id.bt_block6);
        block6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block6.setText("0");
                } else {
                    mState = true;
                    block6.setText("X");
                }
            }
        });

        block7 = (Button) findViewById(R.id.bt_block7);
        block7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block7.setText("0");
                } else {
                    mState = true;
                    block7.setText("X");
                }
            }
        });

        block8 = (Button) findViewById(R.id.bt_block8);
        block8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block8.setText("0");
                } else {
                    mState = true;
                    block8.setText("X");
                }
            }
        });

        block9 = (Button) findViewById(R.id.bt_block9);
        block9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(getState()) {
                    mState = false;
                    block9.setText("0");
                } else {
                    mState = true;
                    block9.setText("X");
                }
            }
        });

        result = (TextView) findViewById(R.id.tv_show_result);
        restart = (Button) findViewById(R.id.bt_restart_game);






        String msg = "Do you want to restart the game";
        /**
         * Restarts the game
         */
        restart.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setMessage("Do you want to restart the game").setTitle("Tic-Tac-Toe")
                //builder.setMessage("Do you want to close this application ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //finish();
                                restart.setText("Restart Game");
                                clearAllButton();
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });

    }

    private boolean getState() {
        return mState;
    }

    private void clearAllButton() {
        block1.setText("");
        block2.setText("");
        block3.setText("");
        block4.setText("");
        block5.setText("");
        block6.setText("");
        block7.setText("");
        block8.setText("");
        block9.setText("");
    }

    private void b1Clicks() {
        String a = block1.getText().toString();
        String b = block2.getText().toString();
        String c = block3.getText().toString();
        String d = block4.getText().toString();
        String e = block7.getText().toString();
        String f = block5.getText().toString();
        String g = block8.getText().toString();
        String bf = new String();
        bf=a+","+b+","+c+","+d+","+e+","+f+","+g+",";
        String st[] = bf.split(",");
        /*for (int i=0; i<st.length-1; i++) {
            if ()
        }*/


    }

}
